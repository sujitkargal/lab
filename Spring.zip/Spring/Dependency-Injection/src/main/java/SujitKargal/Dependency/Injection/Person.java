package SujitKargal.Dependency.Injection;

public class Person {
    private String name;
    private int age;

    // Setter methods for dependency injection
    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void display() {
        System.out.println("Person Name: " + name);
        System.out.println("Person Age: " + age);
    }
}
