package SujitKargal.HelloWorld;

public class HelloWorld {
    public void sayHello() {
        System.out.println("Hello World from Spring Framework!");
    }
}
