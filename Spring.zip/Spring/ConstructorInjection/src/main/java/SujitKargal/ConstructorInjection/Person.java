package SujitKargal.ConstructorInjection;

public class Person {
    private String name;
    private int age;

    // Constructor for dependency injection
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void display() {
        System.out.println("Person Name: " + name);
        System.out.println("Person Age: " + age);
    }
}
