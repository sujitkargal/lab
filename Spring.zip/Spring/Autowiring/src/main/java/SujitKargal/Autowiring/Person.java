package SujitKargal.Autowiring;

public class Person {
    private String name;
    private int age;
    private Address address;  // Dependency

    public Person() {}

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public void display() {
        System.out.println("Person Name: " + name);
        System.out.println("Person Age: " + age);
        System.out.println("Address Details:");
        address.display();
    }
}
