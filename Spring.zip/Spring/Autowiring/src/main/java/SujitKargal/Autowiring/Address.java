package SujitKargal.Autowiring;

public class Address {
    private String city;
    private String state;

    // Default constructor
    public Address() {
    }

    // Setters for Spring dependency injection
    public void setCity(String city) {
        this.city = city;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void display() {
        System.out.println("City: " + city);
        System.out.println("State: " + state);
    }

}
