package SujitKargal.SpringAOP;

import SujitKargal.SpringAOP.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class TestRunner implements CommandLineRunner {

    private final UserService userService;

    public TestRunner(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void run(String... args) throws Exception {
        userService.createUser("Alice");
        System.out.println(userService.getUser(1));

        try {
            userService.updateUser("Bob");
            userService.updateUser("error"); // triggers after throwing advice
        } catch (Exception e) {}

        userService.deleteUser(2);
    }
}
