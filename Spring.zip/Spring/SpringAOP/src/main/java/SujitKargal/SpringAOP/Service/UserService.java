package SujitKargal.SpringAOP.service;

import SujitKargal.SpringAOP.exception.CustomException;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    public void createUser(String name) {
        System.out.println("Creating user: " + name);
    }

    public String getUser(int id) {
        System.out.println("Fetching user with ID: " + id);
        return "User" + id;
    }

    public void updateUser(String name) throws CustomException {
        System.out.println("Updating user: " + name);
        if(name.equals("error")) {
            throw new CustomException("Cannot update user named 'error'");
        }
    }

    public void deleteUser(int id) {
        System.out.println("Deleting user with ID: " + id);
    }
}
