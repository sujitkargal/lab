package SujitKargal.SpringAOP.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    // Pointcut for all methods in UserService
    @Pointcut("execution(* SujitKargal.SpringAOP.service.UserService.*(..))")
    public void userServiceMethods() {}

    // Before advice
    @Before("userServiceMethods()")
    public void beforeAdvice(JoinPoint joinPoint) {
        System.out.println("Before method: " + joinPoint.getSignature().getName());
    }

    // After advice
    @After("userServiceMethods()")
    public void afterAdvice(JoinPoint joinPoint) {
        System.out.println("After method: " + joinPoint.getSignature().getName());
    }

    // Around advice
    @Around("userServiceMethods()")
    public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("Around (Before) method: " + joinPoint.getSignature().getName());
        Object result = joinPoint.proceed();
        System.out.println("Around (After) method: " + joinPoint.getSignature().getName());
        return result;
    }

    // After returning advice
    @AfterReturning(pointcut = "userServiceMethods()", returning = "result")
    public void afterReturningAdvice(JoinPoint joinPoint, Object result) {
        System.out.println("After returning from method: " + joinPoint.getSignature().getName() + ", Result: " + result);
    }

    // After throwing advice
    @AfterThrowing(pointcut = "userServiceMethods()", throwing = "ex")
    public void afterThrowingAdvice(JoinPoint joinPoint, Throwable ex) {
        System.out.println("After throwing exception in method: " + joinPoint.getSignature().getName() + ", Exception: " + ex.getMessage());
    }
}
