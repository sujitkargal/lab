package sujitkargal.springjdbc.dao;

import sujitkargal.springjdbc.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentDaoImpl implements StudentDao {

    private final JdbcTemplate jdbcTemplate;

    public StudentDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void save(Student student) {
        jdbcTemplate.update(
                "INSERT INTO student(name,email,course) VALUES(?,?,?)",
                student.getName(), student.getEmail(), student.getCourse()
        );
    }

    public void update(Student student) {
        jdbcTemplate.update(
                "UPDATE student SET name=?, email=?, course=? WHERE id=?",
                student.getName(), student.getEmail(),
                student.getCourse(), student.getId()
        );
    }

    public void delete(int id) {
        jdbcTemplate.update("DELETE FROM student WHERE id=?", id);
    }

    public Student getById(int id) {
        return jdbcTemplate.queryForObject(
                "SELECT * FROM student WHERE id=?",
                (rs, rowNum) -> {
                    Student s = new Student();
                    s.setId(rs.getInt("id"));
                    s.setName(rs.getString("name"));
                    s.setEmail(rs.getString("email"));
                    s.setCourse(rs.getString("course"));
                    return s;
                }, id
        );
    }

    public List<Student> getAll() {
        return jdbcTemplate.query(
                "SELECT * FROM student",
                (rs, rowNum) -> {
                    Student s = new Student();
                    s.setId(rs.getInt("id"));
                    s.setName(rs.getString("name"));
                    s.setEmail(rs.getString("email"));
                    s.setCourse(rs.getString("course"));
                    return s;
                }
        );
    }
}