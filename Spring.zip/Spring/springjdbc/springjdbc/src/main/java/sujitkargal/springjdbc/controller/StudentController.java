package sujitkargal.springjdbc.controller;

import sujitkargal.springjdbc.dao.StudentDao;
import sujitkargal.springjdbc.model.Student;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class StudentController {

    private final StudentDao studentDao;

    public StudentController(StudentDao studentDao) {
        this.studentDao = studentDao;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("students", studentDao.getAll());
        return "index";
    }

    @PostMapping("/save")
    public String save(Student student) {
        studentDao.save(student);
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable int id, Model model) {
        model.addAttribute("student", studentDao.getById(id));
        model.addAttribute("students", studentDao.getAll());
        return "index";
    }

    @PostMapping("/update")
    public String update(Student student) {
        studentDao.update(student);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable int id) {
        studentDao.delete(id);
        return "redirect:/";
    }
}